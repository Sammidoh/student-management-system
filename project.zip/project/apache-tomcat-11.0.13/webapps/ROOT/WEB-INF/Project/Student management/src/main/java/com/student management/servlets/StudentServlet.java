public package com.studentmanagement.servlets;

import com.studentmanagement.beans.Student;
import com.studentmanagement.ejb.StudentService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;
import java.util.List;

@WebServlet("/students")
public class StudentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private StudentService studentService;
    
    @Override
    public void init() throws ServletException {
        studentService = new StudentService();
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        if (action == null) {
            action = "list";
        }
        
        switch (action) {
            case "new":
                showNewForm(request, response);
                break;
            case "edit":
                showEditForm(request, response);
                break;
            case "delete":
                deleteStudent(request, response);
                break;
            case "search":
                searchStudents(request, response);
                break;
            default:
                listStudents(request, response);
        }
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        if ("insert".equals(action)) {
            insertStudent(request, response);
        } else if ("update".equals(action)) {
            updateStudent(request, response);
        }
    }
    
    private void listStudents(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        List<Student> students = studentService.getAllStudents();
        request.setAttribute("students", students);
        request.getRequestDispatcher("/jsp/students.jsp").forward(request, response);
    }
    
    private void showNewForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        request.getRequestDispatcher("/jsp/student-form.jsp").forward(request, response);
    }
    
    private void showEditForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            Student student = studentService.getStudent(id);
            request.setAttribute("student", student);
            request.getRequestDispatcher("/jsp/student-form.jsp").forward(request, response);
        } catch (NumberFormatException e) {
            response.sendRedirect("students");
        }
    }
    
    private void insertStudent(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        Student student = extractStudentFromRequest(request);
        studentService.addStudent(student);
        response.sendRedirect("students");
    }
    
    private void updateStudent(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            Student student = extractStudentFromRequest(request);
            student.setId(id);
            studentService.updateStudent(student);
            response.sendRedirect("students");
        } catch (NumberFormatException e) {
            response.sendRedirect("students");
        }
    }
    
    private void deleteStudent(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            studentService.deleteStudent(id);
            response.sendRedirect("students");
        } catch (NumberFormatException e) {
            response.sendRedirect("students");
        }
    }
    
    private void searchStudents(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String keyword = request.getParameter("keyword");
        List<Student> students = studentService.searchStudents(keyword);
        request.setAttribute("students", students);
        request.setAttribute("searchKeyword", keyword);
        request.getRequestDispatcher("/jsp/students.jsp").forward(request, response);
    }
    
    private Student extractStudentFromRequest(HttpServletRequest request) {
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String course = request.getParameter("course");
        
        return new Student(0, firstName, lastName, email, phone, new Date(), course);
    }
} {
    
}
