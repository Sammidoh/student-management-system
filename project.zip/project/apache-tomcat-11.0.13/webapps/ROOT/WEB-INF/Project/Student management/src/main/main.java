public package com.studentmanagement.main;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.webapp.WebAppContext;
import java.nio.file.Paths;

public class Main {
    public static void main(String[] args) {
        try {
            // Create server on port 8080
            Server server = new Server(8080);
            
            // Create web app context
            WebAppContext webapp = new WebAppContext();
            webapp.setContextPath("/");
            webapp.setWar(Paths.get("src/main/webapp").toAbsolutePath().toString());
            webapp.setResourceBase(Paths.get("src/main/webapp").toAbsolutePath().toString());
            
            // Extra configuration for JSP support
            webapp.setAttribute("org.eclipse.jetty.server.webapp.ContainerIncludeJarPattern", 
                              ".*/.*jstl.*\\.jar$");
            
            // Set the classloader for JSP
            webapp.setClassLoader(Thread.currentThread().getContextClassLoader());
            
            server.setHandler(webapp);
            
            // Start server
            server.start();
            System.out.println("🎓 Student Management System started!");
            System.out.println("🌐 Open: http://localhost:8080");
            System.out.println("⏹️  Press Ctrl+C to stop the server");
            
            // Wait for server to stop
            server.join();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("❌ Failed to start server: " + e.getMessage());
        }
    }
} {
    
}
