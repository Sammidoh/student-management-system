#!/usr/bin/env bash


mkdir -p StudentManagement/src/main/java/com/studentmanagement/beans
mkdir -p StudentManagement/src/main/java/com/studentmanagement/ejb
mkdir -p StudentManagement/src/main/java/com/studentmanagement/servlets
mkdir -p StudentManagement/src/main/webapp/WEB-INF
mkdir -p StudentManagement/src/main/webapp/jsp
mkdir -p StudentManagement/src/main/webapp/META-INF
return StudentManagement