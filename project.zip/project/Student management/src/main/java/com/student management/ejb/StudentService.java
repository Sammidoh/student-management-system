package com.studentmanagement.ejb;

import com.studentmanagement.beans.Student;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class StudentService {
    private final Map<Integer, Student> students = new ConcurrentHashMap<>();
    private final AtomicInteger idGenerator = new AtomicInteger(1);
    
    public StudentService() {
        initializeSampleData();
    }
    
    private void initializeSampleData() {
        addStudent(new Student(0, "John", "Doe", "john.doe@email.com", 
                "123-456-7890", new Date(), "Computer Science"));
        addStudent(new Student(0, "Jane", "Smith", "jane.smith@email.com", 
                "123-456-7891", new Date(), "Mathematics"));
        addStudent(new Student(0, "Bob", "Johnson", "bob.johnson@email.com", 
                "123-456-7892", new Date(), "Physics"));
    }
    
    public Student addStudent(Student student) {
        int newId = idGenerator.getAndIncrement();
        student.setId(newId);
        students.put(newId, student);
        return student;
    }
    
    public Student getStudent(int id) {
        return students.get(id);
    }
    
    public List<Student> getAllStudents() {
        return new ArrayList<>(students.values());
    }
    
    public Student updateStudent(Student student) {
        if (students.containsKey(student.getId())) {
            students.put(student.getId(), student);
            return student;
        }
        return null;
    }
    
    public boolean deleteStudent(int id) {
        return students.remove(id) != null;
    }
    
    public List<Student> searchStudents(String keyword) {
        List<Student> result = new ArrayList<>();
        String lowerKeyword = keyword.toLowerCase();
        
        for (Student student : students.values()) {
            if (student.getFirstName().toLowerCase().contains(lowerKeyword) ||
                student.getLastName().toLowerCase().contains(lowerKeyword) ||
                student.getEmail().toLowerCase().contains(lowerKeyword) ||
                student.getCourse().toLowerCase().contains(lowerKeyword)) {
                result.add(student);
            }
        }
        return result;
    }
}
